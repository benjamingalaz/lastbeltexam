package com.beltexam.ideasgeniales;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdeasgenialesApplicationTests {

	@Test
	void contextLoads() {
	}

}
