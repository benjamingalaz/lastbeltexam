package com.beltexam.ideasgeniales.models;

public class NewIdea {
    private String content;

    public NewIdea() {

    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public static String getNombreIdea() {
        return null;
    }
}
