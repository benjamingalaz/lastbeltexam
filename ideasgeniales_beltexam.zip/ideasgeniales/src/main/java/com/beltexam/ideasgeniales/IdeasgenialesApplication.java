package com.beltexam.ideasgeniales;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IdeasgenialesApplication {

	public static void main(String[] args) {
		SpringApplication.run(IdeasgenialesApplication.class, args);
	}

}
